package com.cheapestgadget.analytics.dto;

import java.math.BigInteger;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class User {

	private Date date;
	private BigInteger existingUserCounts;
	private BigInteger newUserLogin;

	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public BigInteger getExistingUserCounts() {
		return existingUserCounts;
	}
	public void setExistingUserCounts(BigInteger existingUserCounts) {
		this.existingUserCounts = existingUserCounts;
	}
	public BigInteger getNewUserLogin() {
		return newUserLogin;
	}
	public void setNewUserLogin(BigInteger newUserLogin) {
		this.newUserLogin = newUserLogin;
	}
}
