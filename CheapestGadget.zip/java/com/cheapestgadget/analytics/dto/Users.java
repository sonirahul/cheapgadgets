package com.cheapestgadget.analytics.dto;

public class Users {

	
}
