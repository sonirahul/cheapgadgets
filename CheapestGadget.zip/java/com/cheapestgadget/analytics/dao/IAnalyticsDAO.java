package com.cheapestgadget.analytics.dao;

import com.cheapestgadget.analytics.dto.Analytics;

public interface IAnalyticsDAO {

	boolean insertSearchKeyWords(Analytics keyWords) throws Exception;

	boolean deleteSearchKeyWords();
}
