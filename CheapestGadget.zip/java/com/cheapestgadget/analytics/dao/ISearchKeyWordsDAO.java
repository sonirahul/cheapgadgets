package com.cheapestgadget.analytics.dao;

import com.cheapestgadget.analytics.dto.SearchKeyWords;

public interface ISearchKeyWordsDAO {

	boolean insertSearchKeyWords(SearchKeyWords keyWords) throws Exception;

	boolean deleteSearchKeyWords();
}
