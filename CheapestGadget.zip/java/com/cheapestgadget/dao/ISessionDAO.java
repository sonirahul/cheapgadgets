package com.cheapestgadget.dao;

public interface ISessionDAO {

	void endSession(String sessionID);

	String startSession(String email);

	String findUserEmailBySessionId(String sessionId);

}
