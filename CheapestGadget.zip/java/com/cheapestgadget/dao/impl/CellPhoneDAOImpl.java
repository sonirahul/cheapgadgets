package com.cheapestgadget.dao.impl;

import static com.cheapestgadget.constant.ApplicationConstants.MONGODB_COLLECTION_CELL_PHONES;
import static com.cheapestgadget.constant.ApplicationConstants.MONGODB_COLLECTION_CELL_PHONES_INDEX;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Filters.or;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cheapestgadget.configurator.ApplicationConfigurator;
import com.cheapestgadget.dao.ICellPhoneDAO;
import com.cheapestgadget.dto.product.phone.Phone;
import com.cheapestgadget.utils.CheapestGadgetUtils;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mongodb.ErrorCategory;
import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.FindOneAndUpdateOptions;
import com.mongodb.client.model.ReturnDocument;

@Repository
public class CellPhoneDAOImpl implements ICellPhoneDAO  {

	private static final Logger LOGGER = LoggerFactory.getLogger(CellPhoneDAOImpl.class);

	private final MongoCollection<Document> collection;

	@Autowired(required = true)
	public CellPhoneDAOImpl(ApplicationConfigurator appConfig) {

		collection = appConfig.getMongoDB().getCollection(appConfig.getProperty(MONGODB_COLLECTION_CELL_PHONES));
		String[] indexes = appConfig.getProperty(MONGODB_COLLECTION_CELL_PHONES_INDEX).split(";");
		for (String itr : indexes) {
			collection.createIndex(Document.parse(itr));
		}
	}

	@Override
	public boolean insertCellPhone(Phone cellPhone) throws JsonProcessingException {

		try {
			String jsonInString = CheapestGadgetUtils.javaToJson(cellPhone);
			Document dbObject = Document.parse(jsonInString);
			//collection.deleteOne(eq("_id.productName", "iphone6"));
			collection.insertOne(dbObject);
			return true;
		} catch (JsonProcessingException e) {
			LOGGER.error(MessageFormat.format("Exception occurred while converting java to json, java object: {0}\nException: {1}", cellPhone, e));
			throw e;
		} catch (MongoWriteException e) {
			if (e.getError().getCategory().equals(ErrorCategory.DUPLICATE_KEY)) {
				LOGGER.error("Details already entered: " + cellPhone.getProductId());
				return false;
			}
			throw e;
		}
	}

	@Override
	public List<Phone> fetchCellPhoneByTextIndex(String str) throws Exception {
		List<Phone> phoneList = null;
		try {

			List<Document> cellPhoneList = collection.find(Document.parse("{$text:{$search:'" + str + "'}}"))
					.limit(10).projection(Document.parse("{score: {'$meta': \"textScore\"}}"))
					.sort(Document.parse("{score: {'$meta': \"textScore\"}}")).into(new ArrayList<Document>());

			phoneList = new ArrayList<>();
			for (Document itr: cellPhoneList) {
				phoneList.add(CheapestGadgetUtils.jsonToJava(CheapestGadgetUtils.javaToJson(itr), Phone.class));
			}
			return phoneList;
		} catch (JsonParseException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		} catch (JsonMappingException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		} catch (JsonProcessingException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		} catch (IOException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		}
	}

	@Override
	public List<Phone> fetchCellPhoneByRegex(String str) throws Exception {
		List<Phone> phoneList = null;
		try {
			String[] tokens = str.split(" ");
			Document[] docArr = new Document[tokens.length];

			int i = 0;
			for (String itr : tokens) {
				docArr[i] = Document.parse("{\"_id\": {$regex : \"" + itr + "\"} }");
				i=i++;
			}

			List<Document> cellPhoneList = collection.find(or(docArr)).limit(10).into(new ArrayList<Document>());
			phoneList = new ArrayList<>();
			for (Document itr: cellPhoneList) {
				phoneList.add(CheapestGadgetUtils.jsonToJava(CheapestGadgetUtils.javaToJson(itr), Phone.class));
			}
			return phoneList;
		} catch (JsonParseException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		} catch (JsonMappingException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		} catch (JsonProcessingException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		} catch (IOException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		}
	}

	@Override
	public Phone fetchCellPhoneById(String str) throws Exception {

		try {
			Document update = Document.parse("{\"$inc\" : {\"totalHitCount\":1}}");
			FindOneAndUpdateOptions updateOptions = new FindOneAndUpdateOptions();
			updateOptions.upsert(false);
			updateOptions.returnDocument(ReturnDocument.AFTER);
			Document cellPhone = collection.findOneAndUpdate(eq("_id", str), update, updateOptions );
			if (cellPhone != null) {
				return CheapestGadgetUtils.jsonToJava(CheapestGadgetUtils.javaToJson(cellPhone), Phone.class);
			}
			else {
				return null;
			}
		} catch (JsonParseException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		} catch (JsonMappingException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		} catch (JsonProcessingException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		} catch (IOException e) {
			LOGGER.error(MessageFormat.format("Exception occurred in fetchCellPhone().\nException: {0}", e));
			throw e;
		}
	}
}
