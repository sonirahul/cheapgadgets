package com.cheapestgadget.service.impl;

import static com.cheapestgadget.constant.ApplicationConstants.COOKIE_MAX_AGE;
import static com.cheapestgadget.constant.ApplicationConstants.DATE_TODAY;
import static com.cheapestgadget.constant.ApplicationConstants.NOT_REGISTERED;
import static com.cheapestgadget.constant.ApplicationConstants.REGISTERED;
import static com.cheapestgadget.constant.ApplicationConstants.SESSION_COOKIE;
import static com.cheapestgadget.utils.CheapestGadgetUtils.generateRandomSessionId;
import static com.cheapestgadget.utils.CheapestGadgetUtils.getDateToday;
import static com.cheapestgadget.utils.CheapestGadgetUtils.makePasswordHash;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cheapestgadget.dao.ICellPhoneDAO;
import com.cheapestgadget.dao.ISessionDAO;
import com.cheapestgadget.dao.IUserDAO;
import com.cheapestgadget.dto.product.phone.Phone;
import com.cheapestgadget.dto.user.User;
import com.cheapestgadget.service.ICheapestGadgetService;

@Service
public class CheapestGadgetServiceImpl implements ICheapestGadgetService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CheapestGadgetServiceImpl.class);

	@Autowired private ICellPhoneDAO cellPhoneDao;
	@Autowired private ISessionDAO sessionDao;
	@Autowired private IUserDAO userDao;
	@Autowired private Map<String, Object> cache;

	public CheapestGadgetServiceImpl() {
		cache = new HashMap<String, Object>();
		cache.put(makePasswordHash(REGISTERED, "5F77BDE1981C3A9964E666DD2AE897CA"), REGISTERED);
		cache.put(makePasswordHash(NOT_REGISTERED, "5F77BDE1981C3A9964E666DD2AE897CA"), NOT_REGISTERED);
		cache.put(makePasswordHash(String.valueOf(getDateToday().getTime()), "5F77BDE1981C3A9964E666DD2AE897CA"), DATE_TODAY);
		cache.put(REGISTERED, makePasswordHash(REGISTERED, "5F77BDE1981C3A9964E666DD2AE897CA"));
		cache.put(NOT_REGISTERED, makePasswordHash(NOT_REGISTERED, "5F77BDE1981C3A9964E666DD2AE897CA"));
		cache.put(DATE_TODAY, makePasswordHash(String.valueOf(getDateToday().getTime()), "5F77BDE1981C3A9964E666DD2AE897CA"));
	}

	@Override
	public void createCookie(HttpServletResponse response) {
		createCookie(null, response);
	}

	@Override
	public void createCookie(String cookieValue, HttpServletResponse response) {
		cookieValue = cookieValue == null ? generateCookieValue() : cookieValue;

		Cookie cookie = new Cookie(SESSION_COOKIE, cookieValue); //bake cookie
		cookie.setMaxAge(COOKIE_MAX_AGE); //set expire time to 1 year
		response.addCookie(cookie); //put cookie in response 
	}

	@Override
	public String generateCookieValue() {

		StringBuilder sb = new StringBuilder();
		sb.append(cache.get(NOT_REGISTERED).toString()).append(",");
		sb.append(cache.get(DATE_TODAY).toString()).append(",");
		sb.append(generateRandomSessionId());
		return sb.toString();
	}

	@Override
	public void updateCookieValue(String cookieValue, HttpServletResponse response) {

		String[] cookieTokens = cookieValue.split(",");

		if (cookieTokens.length == 3) {
			if (!cache.get(DATE_TODAY).equals(cookieTokens[1])) {

				StringBuilder sb = new StringBuilder();
				sb.append(cookieTokens[0]).append(",");
				sb.append(cache.get(DATE_TODAY).toString()).append(",");
				sb.append(cookieTokens[2]);
				createCookie(sb.toString(), response);
			}
			else {
				System.out.println("No update required");
			}
		}
		else {
			createCookie(response);
		}
	}

	@Override
	public boolean isUserRegistered(String cookieValue) {
		if (StringUtils.isEmpty(cookieValue)) {
			return false;
		}
		cookieValue = cookieValue.substring(0, cookieValue.indexOf(","));
		return REGISTERED.equals(cache.get(cookieValue));
	}

	public static void main(String[] args) {
		CheapestGadgetServiceImpl obj = new CheapestGadgetServiceImpl();
		String str = obj.generateCookieValue();
		System.out.println(str);
		System.out.println(obj.isUserRegistered(str));
		System.out.println(str);
	}

	@Override
	public User validateUser(User validateUser) {
		return userDao.validateUser(validateUser);
	}

	@Override
	public Phone fetchCellPhoneById(String productName) throws Exception {
		return cellPhoneDao.fetchCellPhoneById(productName);
	}

	@Override
	public boolean insertUser(User validateUser) throws Exception {
		return userDao.insertUser(validateUser);
	}

	@Override
	public void endSession(String cookieValue) {
		sessionDao.endSession(cookieValue);

	}

	@Override
	public User findUserByCookie(String cookieValue) {
		if (StringUtils.isNotEmpty(cookieValue)) {
			try {
				cookieValue = cookieValue.split(",")[2];
				String email = sessionDao.findUserEmailByCookie(cookieValue);
				if (StringUtils.isNotEmpty(email)) {
					return userDao.fetchUserByEmail(email);
				} 
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public void updateUserLastLogin(User user) throws Exception {
		userDao.updateUserLastLogin(user);

	}

	@Override
	public String startSession(String email) {
		// TODO Auto-generated method stub
		return sessionDao.startSession(email);
	}

	@Override
	public List<Phone> fetchCellPhoneByTextIndex(String lowerCase) throws Exception {
		// TODO Auto-generated method stub
		return cellPhoneDao.fetchCellPhoneByTextIndex(lowerCase);
	}

	@Override
	public List<Phone> fetchCellPhoneByRegex(String lowerCase) throws Exception {
		// TODO Auto-generated method stub
		return cellPhoneDao.fetchCellPhoneByRegex(lowerCase);
	}


}
