package com.cheapestgadget.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.cheapestgadget.dto.product.phone.Phone;
import com.cheapestgadget.dto.user.User;

public interface ICheapestGadgetService {

	String generateCookieValue();

	User validateUser(User validateUser);

	Phone fetchCellPhoneById(String productName) throws Exception;

	boolean insertUser(User validateUser) throws Exception;

	User findUserByCookie(String sessionIdCookie);

	List<Phone> fetchCellPhoneByTextIndex(String lowerCase) throws Exception;

	List<Phone> fetchCellPhoneByRegex(String lowerCase) throws Exception;

	boolean isUserRegistered(String cookieValue);

	void updateCookieValue(String cookieValue, HttpServletResponse response);

	String createCookie(String cookieValue, HttpServletResponse response);

	String createCookie(HttpServletResponse response);

	void updateCookieValue(String cookieValue, String email, HttpServletResponse response);

	void endSession(String cookieValue, HttpServletResponse response);
}
