package com.cheapestgadget.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.cheapestgadget.dto.product.phone.Phone;
import com.cheapestgadget.dto.user.User;

public interface ICheapestGadgetService {

	String generateCookieValue();

	User validateUser(User validateUser);

	Phone fetchCellPhoneById(String productName) throws Exception;

	boolean insertUser(User validateUser) throws Exception;

	void endSession(String sessionIdCookie);

	User findUserByCookie(String sessionIdCookie);

	void updateUserLastLogin(User user) throws Exception;

	String startSession(String email);

	List<Phone> fetchCellPhoneByTextIndex(String lowerCase) throws Exception;

	List<Phone> fetchCellPhoneByRegex(String lowerCase) throws Exception;

	void updateCookieValue(String cookieValue, HttpServletResponse response);

	boolean isUserRegistered(String cookieValue);

	void createCookie(HttpServletResponse response);

	void createCookie(String cookieValue, HttpServletResponse response);
}
