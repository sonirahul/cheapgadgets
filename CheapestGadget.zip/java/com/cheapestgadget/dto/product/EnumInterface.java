package com.cheapestgadget.dto.product;

public interface EnumInterface {

	String getValue();

}
