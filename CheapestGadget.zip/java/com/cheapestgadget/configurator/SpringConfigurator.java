package com.cheapestgadget.configurator;

import static com.cheapestgadget.constant.ApplicationConstants.*;
import static com.cheapestgadget.utils.CheapestGadgetUtils.getDateToday;
import static com.cheapestgadget.utils.CheapestGadgetUtils.makePasswordHash;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;
import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;

import com.cheapestgadget.analytics.dto.Analytics;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

@Configuration 
@ComponentScan("com.cheapestgadget") 
@EnableWebMvc
@EnableAspectJAutoProxy
public class SpringConfigurator extends WebMvcConfigurerAdapter {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}

	@Bean
	public FreeMarkerViewResolver viewResolver() {
		FreeMarkerViewResolver viewResolver = new FreeMarkerViewResolver();
		viewResolver.setCache(false);
		viewResolver.setPrefix("");
		viewResolver.setSuffix(".html");
		viewResolver.setRequestContextAttribute("rc");
		return viewResolver;
	}

	@Bean
	public FreeMarkerConfigurer freemarkerConfig(ApplicationConfigurator appConfig) {
		FreeMarkerConfigurer freemarkerConfig = new FreeMarkerConfigurer();
		freemarkerConfig.setTemplateLoaderPath(appConfig.getProperty(VIEWS_LOC));
		return freemarkerConfig;
	}

	@Bean
	public MongoClient mongoClient(ApplicationConfigurator appConfig) {
		MongoClient mongoClient = new MongoClient(new MongoClientURI(appConfig.getProperty(MONGODB_URL)));
		return mongoClient;
	}

	@Bean
	public Analytics keyWords() {
		Analytics keyWords = new Analytics();
		keyWords.setDate(getDateToday());
		return keyWords;
	}

	@Bean
	public Map<String, Object> cache(ApplicationConfigurator appConfig) {
		Map<String, Object> cache = new HashMap<String, Object>();
		cache.put(makePasswordHash(REGISTERED, appConfig.getProperty(ENCRYPTION_SALT)), REGISTERED);
		cache.put(makePasswordHash(REGISTERED_lOGGED_OFF, appConfig.getProperty(ENCRYPTION_SALT)), REGISTERED_lOGGED_OFF);
		cache.put(makePasswordHash(NOT_REGISTERED, appConfig.getProperty(ENCRYPTION_SALT)), NOT_REGISTERED);
		cache.put(makePasswordHash(String.valueOf(getDateToday().getTime()), appConfig.getProperty(ENCRYPTION_SALT)), DATE_TODAY);
		cache.put(REGISTERED, makePasswordHash(REGISTERED, appConfig.getProperty(ENCRYPTION_SALT)));
		cache.put(REGISTERED_lOGGED_OFF, makePasswordHash(REGISTERED_lOGGED_OFF, appConfig.getProperty(ENCRYPTION_SALT)));
		cache.put(NOT_REGISTERED, makePasswordHash(NOT_REGISTERED, appConfig.getProperty(ENCRYPTION_SALT)));
		cache.put(DATE_TODAY, makePasswordHash(String.valueOf(getDateToday().getTime()), appConfig.getProperty(ENCRYPTION_SALT)));
		
		for (Entry<String, Object> itr : cache.entrySet()) {
			System.out.println(itr.getKey() + ", " + itr.getValue());
		}
		return cache;
	}
}