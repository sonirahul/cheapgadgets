package com.cheapestgadget.configurator;

import static com.cheapestgadget.constant.ApplicationConstants.MONGODB_URL;
import static com.cheapestgadget.constant.ApplicationConstants.VIEWS_LOC;
import static com.cheapestgadget.utils.CheapestGadgetUtils.*;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;
import org.springframework.web.servlet.view.freemarker.FreeMarkerViewResolver;

import com.cheapestgadget.analytics.dto.SearchKeyWords;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;

@Configuration 
@ComponentScan("com.cheapestgadget") 
@EnableWebMvc
@EnableAspectJAutoProxy
public class SpringConfigurator extends WebMvcConfigurerAdapter {

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}

	@Bean
	public FreeMarkerViewResolver viewResolver() {
		FreeMarkerViewResolver viewResolver = new FreeMarkerViewResolver();
		viewResolver.setCache(false);
		viewResolver.setPrefix("");
		viewResolver.setSuffix(".html");
		viewResolver.setRequestContextAttribute("rc");
		return viewResolver;
	}

	@Bean
	public FreeMarkerConfigurer freemarkerConfig(ApplicationConfigurator appConfig) {
		FreeMarkerConfigurer freemarkerConfig = new FreeMarkerConfigurer();
		freemarkerConfig.setTemplateLoaderPath(appConfig.getProperty(VIEWS_LOC));
		return freemarkerConfig;
	}

	@Bean
	public MongoClient mongoClient(ApplicationConfigurator appConfig) {
		MongoClient mongoClient = new MongoClient(new MongoClientURI(appConfig.getProperty(MONGODB_URL)));
		return mongoClient;
	}

	@Bean
	public SearchKeyWords keyWords() {
		SearchKeyWords keyWords = new SearchKeyWords();
		keyWords.setDate(getDateToday());
		return keyWords;
	}
}