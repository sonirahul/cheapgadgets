package com.cheapestgadget.controller;

import static com.cheapestgadget.constant.ApplicationConstants.INDEX_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.PHONE;
import static com.cheapestgadget.constant.ApplicationConstants.PRODUCT_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.SESSION_COOKIE;
import static com.cheapestgadget.constant.ApplicationConstants.SESSION_COOKIE_DEFAULT;
import static com.cheapestgadget.constant.ApplicationConstants.SESSION_MAX_INACTIVE_INTERVAL;
import static com.cheapestgadget.constant.ApplicationConstants.USER;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cheapestgadget.configurator.ApplicationConfigurator;
import com.cheapestgadget.dto.product.phone.Phone;
import com.cheapestgadget.dto.user.User;
import com.cheapestgadget.service.ICheapestGadgetService;

@Controller
public class CheapestGadgetController {



	private static final Logger LOGGER = LoggerFactory.getLogger(CheapestGadgetController.class);

	@Autowired private ApplicationConfigurator appConfig;
	@Autowired private ICheapestGadgetService service;

	@RequestMapping(value = {"/", "/index"}, method = RequestMethod.GET)
	public ModelAndView index(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		ModelAndView mv = new ModelAndView(INDEX_PAGE);
		User user = getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		return mv;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(User validateUser, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		User user = service.validateUser(validateUser);
		if(user != null) {
			session.setAttribute(USER, user);
			session.setMaxInactiveInterval(
					Integer.valueOf(appConfig.getProperty(SESSION_MAX_INACTIVE_INTERVAL)));
			generateCookie(user.getEmail(), response);
		}
		user = getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			throw new Exception("Error: User already logged in, it shouldn't happen");
		}
		else {
			
		}

		/*
		 * 	<#if (userNameya)??>${userNameya}<#else>boo</#if>
			<#if (user.email)??>${user.email}<#else>boo</#if>
			<#if (user)??>${user}<#else>boo</#if>
			<#if cars??>
    		<#list cars as car>${car.owner};</#list>
			</#if>
		 */
		return "redirect:welcome";
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String search(String query, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		return "redirect:product/"+query;
	}

	@RequestMapping(value = "/product/{productName}", method = RequestMethod.GET) 
	public ModelAndView getProduct(@PathVariable String productName, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {
		ModelAndView mv = new ModelAndView(PRODUCT_PAGE);
		User user = getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		Phone phone = service.fetchCellPhoneById(productName);
		if (phone != null) {
			mv.addObject(PHONE, phone);
		}

		return mv;
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public ModelAndView loginGet(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {
		ModelAndView mv = new ModelAndView(INDEX_PAGE);
		User user = getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		return mv;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String register(User validateUser, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {
		User user = null;
		user = getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			throw new Exception("Error: User already logged in, it shouldn't happen");
		}
		else {
			if (service.insertUser(validateUser)) {
				session.setAttribute(USER, validateUser);
				session.setMaxInactiveInterval(
						Integer.valueOf(appConfig.getProperty(SESSION_MAX_INACTIVE_INTERVAL)));
				generateCookie(validateUser.getEmail(), response);
			}
		}
		return "redirect:welcome";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) {
		if (session.getAttribute(USER) != null) {
			session.removeAttribute(USER);
			session.invalidate();
			service.endSession(cookieValue);
		}
		/*if (!SESSION_COOKIE_DEFAULT.equals(cookieValue)) {
			Cookie cookie = new Cookie(SESSION_COOKIE, null);
			cookie.setMaxAge(0);
			response.addCookie(cookie);
		}*/
		return "redirect:index";
	}

	private User getLoggedInUser(String cookieValue, HttpSession session, 
			HttpServletResponse response) throws Exception {

		User user = null;

		// New User
		if (SESSION_COOKIE_DEFAULT.equals(cookieValue)) {
			service.createCookie(cookieValue, response);
		}
		// Existing User
		else {
			service.updateCookieValue(cookieValue, response);

			if (session.getAttribute(USER) != null) {
				user = (User)session.getAttribute(USER);
			}
			else {
				if (service.isUserRegistered(cookieValue)) {
					LOGGER.debug("Available user in cookie is registered, setting in session");
					user = service.findUserByCookie(cookieValue);
					if (user != null) {
						session.setAttribute(USER, user);
						session.setMaxInactiveInterval(
								Integer.valueOf(appConfig.getProperty(SESSION_MAX_INACTIVE_INTERVAL)));
					}
				}
				else {
					LOGGER.debug("Available user in cookie is not registered");
				}
			}
		}
		return user;
	}

	/*private void updateUserWithLoginDetails(User user) throws Exception {
		service.updateUserLastLogin(user);
	}*/

	/*private void generateCookie(String email, HttpServletResponse response) {
		String sessionId = service.startSession(email);
		if (sessionId == null) {
			//response.redirect("/internal_error");
		}
		else {
			Cookie cookie = new Cookie(SESSION_COOKIE, sessionId); //bake cookie
			cookie.setMaxAge(2592000); //set expire time to 1000 sec
			response.addCookie(cookie); //put cookie in response 
		}
	}*/

	@RequestMapping(value = "/getTags", method = RequestMethod.GET)
	public @ResponseBody
	List<Tag> getTags(@RequestParam String tagName) throws Exception {
		List<Tag> result = new ArrayList<Tag>();

		List<Phone> phoneList = service.fetchCellPhoneByTextIndex(tagName.toLowerCase());

		if (CollectionUtils.isEmpty(phoneList)) {
			phoneList = service.fetchCellPhoneByRegex(tagName.toLowerCase());
		}
		for (Phone itr : phoneList) {
			result.add(new Tag(phoneList.indexOf(itr), itr.getProductId()));
		}
		return result;
	}
}
class Tag {

	public int id;
	public String tagName;

	//getter and setter methods

	public Tag(int id, String tagName) {
		this.id = id;
		this.tagName = tagName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

}