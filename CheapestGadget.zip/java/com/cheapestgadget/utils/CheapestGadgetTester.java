package com.cheapestgadget.utils;

import static com.cheapestgadget.utils.CheapestGadgetUtils.getDateNDaysFromToday;

import java.math.BigDecimal;
import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cheapestgadget.analytics.dao.IHitsTrackerDAO;
import com.cheapestgadget.analytics.dao.IAnalyticsDAO;
import com.cheapestgadget.analytics.dao.impl.HitsTrackerDAOImpl;
import com.cheapestgadget.analytics.dao.impl.AnalyticsDAOImpl;
import com.cheapestgadget.analytics.dto.Keys;
import com.cheapestgadget.analytics.dto.Analytics;
import com.cheapestgadget.configurator.SpringConfigurator;
import com.cheapestgadget.dao.ICellPhoneDAO;
import com.cheapestgadget.dao.IUserDAO;
import com.cheapestgadget.dao.impl.CellPhoneDAOImpl;
import com.cheapestgadget.dao.impl.UserDAOImpl;
import com.cheapestgadget.dto.product.phone.Phone;
import com.cheapestgadget.dto.user.User;
import com.cheapestgadget.dto.user.UserRole;

public class CheapestGadgetTester {

	private static final Logger LOGGER = LoggerFactory.getLogger(CheapestGadgetTester.class);

	@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception {
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfigurator.class);
		ICellPhoneDAO cellDao = context.getBean(CellPhoneDAOImpl.class);
		Phone phone  = CheapestGadgetHardCodeHelper.getSampleCellPhone();

		String[] manufacturer = "samsung,sony,apple,lg,motorola,htc,lava,micromax,oneplus,oppo,nokia,xolo,carbon".split(",");
		int length = manufacturer.length;
		for (int i = 0 ; i < 10000 ; i ++ ) {
			int index = i%length;
			phone.setManufacturer(manufacturer[index]);
			phone.getModels().get(0).getDisplay().setSize(BigDecimal.valueOf(Math.round(ThreadLocalRandom.current().nextDouble(3.0, 5.0 + 1) * 10)/10.0));
			phone.getModels().get(0).getMemory().setRam(BigDecimal.valueOf(ThreadLocalRandom.current().nextInt(1, 4 + 1)));
			phone.setProductName(String.valueOf(i)); 
			cellDao.insertCellPhone(phone);
		}
		Phone phoneFromDB = cellDao.fetchCellPhoneById("samsung 0");
		//System.out.println(phoneFromDB.getModels().get(0).getSimSlotCount());
		//System.out.println(CheapestGadgetUtils.javaToJsonPretty(phoneFromDB));
		IUserDAO userDao = context.getBean(UserDAOImpl.class);
		userDao.insertUser(CheapestGadgetHardCodeHelper.getSampleUser(UserRole.ADMIN));
		User user = userDao.fetchUserByEmail("soni_rahul@live.com");
		userDao.updateUserLastLogin(user);
		LOGGER.debug(userDao.fetchUserByEmail("soni_rahul@live.com").getLastLogin().toString());
		IHitsTrackerDAO hitsDao = context.getBean(HitsTrackerDAOImpl.class);
		hitsDao.updateHitCount("samsung 0");
		System.out.println(hitsDao.getProductHitCountInNDays("samsung 0", -3));
		
		IAnalyticsDAO keyDAO = context.getBean(AnalyticsDAOImpl.class);
		Analytics key = context.getBean(Analytics.class);

		for (int i = 0; i < 40; i ++ ) {
			key.setDate(getDateNDaysFromToday(i * -1 , false));
			key.getKeyWords().add(new Keys("test", i%2 == 0 ? true : false)); 
			key.getKeyWords().add(new Keys("test1", i%2 == 0 ? true : false)); 
			keyDAO.insertSearchKeyWords(key);
			key.getKeyWords().clear();
		}
		keyDAO.deleteSearchKeyWords();

	}
	


}
