package com.cheapestgadget.aop;

import java.util.Arrays;
import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cheapestgadget.dto.analytics.Keywords;

@Aspect
@Component
public class CheapestGadgetAspect {

	private static final Logger LOGGER = LoggerFactory.getLogger(CheapestGadgetAspect.class);
	@Autowired Keywords keywords;

	@Around("allMethodsPointcut()")
	public Object employeeAroundAdvice(ProceedingJoinPoint proceedingJoinPoint){
		String methodSig=proceedingJoinPoint.toString().substring(proceedingJoinPoint.toString().indexOf("("));
		LOGGER.debug("Executing method=" + methodSig + 
				", Arguments passed=" + Arrays.toString(proceedingJoinPoint.getArgs()));
		Object value = null;
		Date before = null;
		Date after = null;
		try {
			before = new Date();
			value = proceedingJoinPoint.proceed();
			after = new Date();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		long timeTaken = after.getTime() - before.getTime();
		LOGGER.debug("Executed method=" + methodSig +  ", Return value="+value +
				", Time taken=" + timeTaken);
		return value;
	}

	@Pointcut("within(com.cheapestgadget.controller.*) || within(com.cheapestgadget.dao.impl.*)")
	public void allMethodsPointcut(){}

	@Before("execution(* com.cheapestgadget.dao.impl.CellPhoneDAOImpl.fetchCellPhoneById(..))")
	public void test(JoinPoint joinPoint) {
		LOGGER.debug("Arrey wah test is working " + joinPoint.getArgs());
		for (Object itr : joinPoint.getArgs()) {
			keywords.getKeywords().add((String) itr);
		}
	}
}
