package com.cheapestgadget.analytics.dao;

public interface IUserAnalytics {
}
