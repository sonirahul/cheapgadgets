package com.cheapestgadget.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cheapestgadget.dto.product.phone.Phone;
import com.cheapestgadget.dto.user.User;

public interface ICheapestGadgetService {

	String generateCookieValue();

	User validateUser(User validateUser);

	Phone fetchCellPhoneById(String productName) throws Exception;

	boolean insertUser(User validateUser) throws Exception;

	User findUserByCookie(String sessionIdCookie);

	String getRegistrationStatus(String cookieValue);

	void updateCookieValue(String cookieValue, HttpServletResponse response);

	String createCookie(String cookieValue, HttpServletResponse response);

	String createCookie(HttpServletResponse response);

	void updateCookieValue(String cookieValue, String email, HttpServletResponse response);

	void endSession(String cookieValue, HttpServletResponse response);

	User getLoggedInUser(String cookieValue, HttpSession session,
			HttpServletResponse response) throws Exception;

	User findUserByEmail(String email, boolean updateLastLogin) throws Exception;

	List<Phone> fetchCellPhoneByTextIndex(String searchStr, int limit) throws Exception;

	List<Phone> fetchCellPhoneByRegex(String searchStr, int limit) throws Exception;
}
