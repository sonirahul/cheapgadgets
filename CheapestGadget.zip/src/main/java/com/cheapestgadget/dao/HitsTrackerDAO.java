package com.cheapestgadget.dao;

public interface HitsTrackerDAO {

	boolean updateHitCount(String productId) throws Exception;

	Integer getProductHitCountInNDays(String productId, Integer nDays) throws Exception;
}
