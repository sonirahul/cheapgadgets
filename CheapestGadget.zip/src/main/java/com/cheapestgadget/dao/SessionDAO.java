package com.cheapestgadget.dao;

public interface SessionDAO {

	void endSession(String sessionID);

	String startSession(String email);

	String findUserEmailBySessionId(String sessionId);

}
