package com.cheapestgadget.dao;

import java.util.List;

import com.cheapestgadget.dto.compare.ICompareProduct;
import com.cheapestgadget.dto.product.phone.Phone;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface ICellPhoneDAO {

	boolean insertCellPhone(Phone cellPhone) throws JsonProcessingException;

	Phone fetchCellPhoneById(String str) throws Exception;

	List<Phone> fetchCellPhoneByRegex(String[] searchArr, int skip, int limit, ICompareProduct comparator)
			throws Exception;

	List<Phone> fetchCellPhoneByTextIndex(String searchArr, int skip, int limit, ICompareProduct comparator)
			throws Exception;

	List<Phone> fetchCellPhoneByTextIndex(String[] searchArr, int skip, int limit, ICompareProduct comparator)
			throws Exception;

}
