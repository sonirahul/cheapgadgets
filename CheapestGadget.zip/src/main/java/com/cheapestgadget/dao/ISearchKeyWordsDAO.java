package com.cheapestgadget.dao;

import com.cheapestgadget.dto.analytics.SearchKeyWords;

public interface ISearchKeyWordsDAO {

	boolean insertSearchKeyWords(SearchKeyWords keyWords);

	boolean deleteSearchKeyWords();
}
