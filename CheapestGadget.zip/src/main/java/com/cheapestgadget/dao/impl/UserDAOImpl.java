package com.cheapestgadget.dao.impl;

import static com.cheapestgadget.constant.ApplicationConstants.COMMA;
import static com.cheapestgadget.constant.ApplicationConstants.EMAIL;
import static com.cheapestgadget.constant.ApplicationConstants.MD5;
import static com.cheapestgadget.constant.ApplicationConstants.MONGODB_COLLECTION_USERS;
import static com.cheapestgadget.constant.ApplicationConstants.MONGODB_COLLECTION_USERS_INDEX;
import static com.cheapestgadget.constant.ApplicationConstants.MONGODB_FIELD_ID;
import static com.cheapestgadget.constant.ApplicationConstants.PASSWORD;
import static com.cheapestgadget.constant.ApplicationConstants.UTF_8;
import static com.cheapestgadget.utils.CheapestGadgetUtils.generateCustomErrorMessage;
import static com.cheapestgadget.utils.CheapestGadgetUtils.getDateTimeToday;
import static com.cheapestgadget.utils.CheapestGadgetUtils.javaToJson;
import static com.cheapestgadget.utils.CheapestGadgetUtils.jsonToJava;
import static com.mongodb.client.model.Filters.eq;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;
import org.bson.Document;
import org.bson.json.JsonParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cheapestgadget.configurator.ApplicationConfigurator;
import com.cheapestgadget.dao.IUserDAO;
import com.cheapestgadget.dto.user.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.mongodb.ErrorCategory;
import com.mongodb.MongoWriteException;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.IndexOptions;
import com.mongodb.client.result.UpdateResult;

@Repository
public class UserDAOImpl implements IUserDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserDAOImpl.class);

	private final MongoCollection<Document> collection;
	private Random random = new SecureRandom();

	@Autowired(required = true)
	public UserDAOImpl(ApplicationConfigurator appConfig) {
		collection = appConfig.getMongoDB().getCollection(appConfig.getProperty(MONGODB_COLLECTION_USERS));
		IndexOptions indexOptions = new IndexOptions();
		indexOptions.unique(true);
		indexOptions.sparse(true);
		collection.createIndex(Document.parse(appConfig.getProperty(MONGODB_COLLECTION_USERS_INDEX)), indexOptions);
	}

	@Override
	public boolean insertUser(User user) throws Exception {
		try {
			user.setPassword(makePasswordHash(user.getPassword(), Integer.toString(random.nextInt())));
			String jsonInString = javaToJson(user);
			Document dbObject = Document.parse(jsonInString);
			collection.insertOne(dbObject);
			return true;
		} catch (JsonProcessingException e) {
			LOGGER.error("Exception Occured: " + e);
			throw e;
		} catch (MongoWriteException e) {
			if (e.getError().getCategory().equals(ErrorCategory.DUPLICATE_KEY)) {
				LOGGER.error(generateCustomErrorMessage(e.getMessage()));
				return false;
			}
			throw e;
		}
	}

	@Override
	public User fetchUserByEmail(String email) throws Exception {
		try {
			Document user = collection.find(eq(MONGODB_FIELD_ID, email)).first();
			if (user != null) {
				return jsonToJava(javaToJson(user), User.class);
			}
			else {
				return null;
			}
		} catch (JsonParseException e) {
			LOGGER.error("Exception Occured: " + e);
			throw e;
		} catch (JsonMappingException e) {
			LOGGER.error("Exception Occured: " + e);
			throw e;
		} catch (JsonProcessingException e) {
			LOGGER.error("Exception Occured: " + e);
			throw e;
		} catch (IOException e) {
			LOGGER.error("Exception Occured: " + e);
			throw e;
		}
	}

	@Override
	public boolean updateUser(User user) throws Exception {
		try {
			String jsonInString = javaToJson(user);
			Document dbObject = Document.parse(jsonInString);
			UpdateResult db = collection.replaceOne(eq(EMAIL, user.getEmail()), dbObject);
			return db.isModifiedCountAvailable();
		} catch (JsonProcessingException e) {
			LOGGER.error("Exception Occured: " + e);
			throw e;
		}
	}

	@Override
	public boolean updateUserLastLogin(User user) throws Exception {
		try {
			Document query = new Document(MONGODB_FIELD_ID, user.getEmail());
			String json = "{\"$set\": {\"lastLogin\":" + javaToJson(getDateTimeToday()) + "}}";
			Document update = Document.parse(json);
			UpdateResult db = collection.updateOne(query, update);
			return db.isModifiedCountAvailable();
		} catch (JsonProcessingException e) {
			LOGGER.error("Exception Occured: " + e);
			throw e;
		}
	}

	@Override
	public User validateUser(User user) {

		try {
			Document dbUser = collection.find(eq(MONGODB_FIELD_ID, user.getEmail())).first();

			if (dbUser == null) {
				LOGGER.debug("User not in database");
				return null;
			}

			String hashedAndSalted = dbUser.get(PASSWORD).toString();

			String salt = hashedAndSalted.split(COMMA)[1];

			if (!hashedAndSalted.equals(makePasswordHash(user.getPassword(), salt))) {
				LOGGER.debug("Submitted password is not a match");
				return null;
			}

			return jsonToJava(javaToJson(dbUser), User.class);
		} catch (com.fasterxml.jackson.core.JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	private String makePasswordHash(String password, String salt) {
		try {
			String saltedAndHashed = password + COMMA + salt;
			MessageDigest digest = MessageDigest.getInstance(MD5);
			digest.update(saltedAndHashed.getBytes());

			Base64 newEncoder = new Base64();
			byte hashedBytes[] = (new String(digest.digest(), UTF_8)).getBytes();
			return newEncoder.encodeToString(hashedBytes) + COMMA + salt;
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("MD5 is not available", e);
		} catch (UnsupportedEncodingException e) {
			throw new RuntimeException("UTF-8 unavailable?  Not a chance", e);
		}
	}
}
