package com.cheapestgadget.dao.impl;

import static com.cheapestgadget.constant.ApplicationConstants.EMAIL;
import static com.cheapestgadget.constant.ApplicationConstants.MONGODB_COLLECTION_SESSIONS;
import static com.cheapestgadget.constant.ApplicationConstants.MONGODB_FIELD_ID;
import static com.mongodb.client.model.Filters.eq;

import java.security.SecureRandom;
import org.apache.commons.codec.binary.Base64;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cheapestgadget.configurator.ApplicationConfigurator;
import com.cheapestgadget.dao.SessionDAO;
import com.mongodb.client.MongoCollection;

@Repository
public class SessionDAOImpl implements SessionDAO {

	private final MongoCollection<Document> collection;

    @Autowired
    public SessionDAOImpl(ApplicationConfigurator appConfig) {
        collection = appConfig.getMongoDB().getCollection(appConfig.getProperty(MONGODB_COLLECTION_SESSIONS));
    }

    @Override
    public String findUserEmailBySessionId(String sessionId) {
        Document session = getSession(sessionId);

        if (session == null) {
            return null;
        }
        else {
            return session.get(EMAIL).toString();
        }
    }

    @Override
    // starts a new session in the sessions table
    public String startSession(String email) {

        // get 32 byte random number. that's a lot of bits.
        SecureRandom generator = new SecureRandom();
        byte randomBytes[] = new byte[32];
        generator.nextBytes(randomBytes);

        Base64 encoder = new Base64();
        String sessionID = encoder.encodeToString(randomBytes);

        // build the BSON object
        Document session = new Document(EMAIL, email)
                           .append(MONGODB_FIELD_ID, sessionID);

        collection.insertOne(session);

        return session.getString(MONGODB_FIELD_ID);
    }

    @Override
    // ends the session by deleting it from the sesisons table
    public void endSession(String sessionID) {
        collection.deleteOne(eq(MONGODB_FIELD_ID, sessionID));
    }

    // retrieves the session from the sessions table
    private Document getSession(String sessionID) {
        return collection.find(eq(MONGODB_FIELD_ID, sessionID)).first();
    }
}
