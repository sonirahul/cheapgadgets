package com.cheapestgadget.dao.impl;

import static com.cheapestgadget.constant.ApplicationConstants.MONGODB_COLLECTION_ANALYTICS_KEYWORDS;
import static com.cheapestgadget.constant.ApplicationConstants.MONTH_AGO;
import static com.cheapestgadget.utils.CheapestGadgetUtils.getDateNDaysFromToday;
import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cheapestgadget.configurator.ApplicationConfigurator;
import com.cheapestgadget.dao.ISearchKeyWordsDAO;
import com.cheapestgadget.dto.analytics.SearchKeyWords;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;

@Repository
public class SearchKeywordsDAOImpl implements ISearchKeyWordsDAO {

	private final MongoCollection<Document> collection;

	@Autowired
	public SearchKeywordsDAOImpl(ApplicationConfigurator appConfig) {
		collection = appConfig.getMongoDB().getCollection(appConfig.getProperty(MONGODB_COLLECTION_ANALYTICS_KEYWORDS));
	}

	@Override
	public boolean insertSearchKeyWords(SearchKeyWords keywords) {
		if (!keywords.getKeyWords().isEmpty()) {
			StringBuilder sb = new StringBuilder();
			for (String itr : keywords.getKeyWords()) {
				sb.append("\"" + itr + "\",");
			}
			Document update = 
					Document.parse("{\"$pushAll\" : {\"keywords\" : [" + sb.substring(0, sb.lastIndexOf(",")).toString() + "]}}");
			UpdateOptions updateOptions = new UpdateOptions();
			updateOptions.upsert(true);
			UpdateResult result = collection.updateOne(eq("_id", keywords.getDate().getTime()), 
					update, updateOptions );
			return result.isModifiedCountAvailable();
		}
		else {
			return false;
		}
	}

	@Override
	public boolean deleteSearchKeyWords() {
		Document query = Document.parse("{\"_id\" : {\"$lte\" : " + getDateNDaysFromToday(MONTH_AGO, false).getTime() + "}}");
		DeleteResult result = collection.deleteMany(query);
		return result.getDeletedCount() >= 1 ? true : false;
	}
}
