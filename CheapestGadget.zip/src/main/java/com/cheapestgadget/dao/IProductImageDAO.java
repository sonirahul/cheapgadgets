package com.cheapestgadget.dao;

import com.cheapestgadget.dto.product.ProductImage;

public interface IProductImageDAO {

	boolean insertProductImage(ProductImage image) throws Exception;

	ProductImage fetchProductImage(String productId) throws Exception;
}
