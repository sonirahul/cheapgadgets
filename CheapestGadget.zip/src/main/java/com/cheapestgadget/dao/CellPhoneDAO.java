package com.cheapestgadget.dao;

import java.util.List;

import com.cheapestgadget.dto.product.phone.Phone;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface CellPhoneDAO {

	boolean insertCellPhone(Phone cellPhone) throws JsonProcessingException;

	List<Phone> fetchCellPhoneByTextIndex(String str) throws Exception;

	List<Phone> fetchCellPhoneByRegex(String str) throws Exception;

	Phone fetchCellPhoneById(String str) throws Exception;

}
