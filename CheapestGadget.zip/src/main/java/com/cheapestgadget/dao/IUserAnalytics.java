package com.cheapestgadget.dao;

public interface IUserAnalytics {
}
