package com.cheapestgadget.dao;

import com.cheapestgadget.dto.analytics.Keywords;

public interface KeywordsDAO {

	boolean insertKeywords(Keywords keywords);

	boolean deleteKeywords();
}
