package com.cheapestgadget.cron;

import static com.cheapestgadget.utils.CheapestGadgetUtils.getDateTimeToday;
import static com.cheapestgadget.utils.CheapestGadgetUtils.getDateToday;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.cheapestgadget.dao.KeywordsDAO;
import com.cheapestgadget.dto.analytics.Keywords;

@Service
@EnableScheduling
public class CronJob {

	@Autowired Keywords keywords;
	@Autowired KeywordsDAO keyDAO;

	@Scheduled(cron="1 0 0 * * ?")
	public void dailyCleanUpTasks()
	{
		keywords.setDate(getDateToday());
		keyDAO.deleteKeywords();
	}

	@Scheduled(cron="0 */10 * * * ?")
	public void updateKeywords()
	{
		System.out.println("Cron job run after every ten min: " + getDateTimeToday());
		if (keyDAO.insertKeywords(keywords)) {
			keywords.getKeywords().clear();
		}
	}

}
