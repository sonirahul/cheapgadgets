package com.cheapestgadget.dto.analytics;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SearchKeyWords {

	@JsonProperty("_id")
	private Date date;
	private List<String> keyWords;

	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public List<String> getKeyWords() {
		if (keyWords == null){
			keyWords = new ArrayList<>();
		}
		return keyWords;
	}

	@Override
	public String toString() {
		return "SearchKeyWords [date=" + date + ", keyWords=" + keyWords + "]";
	}
}
