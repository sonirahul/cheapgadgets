package com.cheapestgadget.dto.analytics;

public class Users {

	
}
