package com.cheapestgadget.dto.analytics;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Keywords {

	@JsonProperty("_id")
	private Date date;
	private List<String> keywords;

	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public List<String> getKeywords() {
		if (keywords == null){
			keywords = new ArrayList<>();
		}
		return keywords;
	}
	
}
