package com.cheapestgadget.dto.compare;

import java.util.Comparator;

import com.cheapestgadget.dto.product.phone.Phone;

public interface ICompareProduct extends Comparator<Phone> {

}
