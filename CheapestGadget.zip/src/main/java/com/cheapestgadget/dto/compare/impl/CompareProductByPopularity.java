package com.cheapestgadget.dto.compare.impl;

import com.cheapestgadget.dto.compare.ICompareProduct;
import com.cheapestgadget.dto.product.phone.Phone;

public class CompareProductByPopularity implements ICompareProduct {

	@Override
	public int compare(Phone o1, Phone o2) {
		return o2.getTotalHitCount().compareTo(o1.getTotalHitCount());
	}
}
