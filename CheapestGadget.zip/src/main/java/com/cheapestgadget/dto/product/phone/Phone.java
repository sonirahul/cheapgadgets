package com.cheapestgadget.dto.product.phone;

import java.util.ArrayList;
import java.util.List;

import com.cheapestgadget.dto.product.Product;

public class Phone extends Product {

	private List<PhoneModel> models;

	public List<PhoneModel> getModels() {
		if (models == null) {
			models = new ArrayList<>();
		}
		return models;
	}
	@Override
	public String toString() {
		return "Phone [models=" + models + ", toString()=" + super.toString() + "]";
	}
}
