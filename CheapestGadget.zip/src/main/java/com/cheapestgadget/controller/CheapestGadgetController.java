package com.cheapestgadget.controller;

import static com.cheapestgadget.constant.ApplicationConstants.COMPARE_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.INDEX_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.LOGIN_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.PHONE;
import static com.cheapestgadget.constant.ApplicationConstants.PHONE_LIST;
import static com.cheapestgadget.constant.ApplicationConstants.PRODUCT_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.SEARCH_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.SESSION_COOKIE;
import static com.cheapestgadget.constant.ApplicationConstants.SESSION_COOKIE_DEFAULT;
import static com.cheapestgadget.constant.ApplicationConstants.USER;

import java.util.LinkedHashSet;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cheapestgadget.dto.product.phone.Phone;
import com.cheapestgadget.dto.user.User;
import com.cheapestgadget.service.ICheapestGadgetService;

@RestController
public class CheapestGadgetController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CheapestGadgetController.class);

	@Autowired private ICheapestGadgetService service;

	@RequestMapping(value = {"/", "/index"}, method = RequestMethod.GET)
	public ModelAndView index(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		ModelAndView mv = new ModelAndView(INDEX_PAGE);
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		return mv;
	}

	@RequestMapping(value = {"/login"}, method = RequestMethod.GET)
	public ModelAndView login(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response, final RedirectAttributes redirectAttributes) throws Exception {

		ModelAndView mv = null;
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv = new ModelAndView("redirect:/welcome");
			redirectAttributes.addFlashAttribute("user", user);
		}
		else {
			mv = new ModelAndView(LOGIN_PAGE);
		}
		return mv;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(User validateUser, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response, final RedirectAttributes redirectAttributes) throws Exception {

		User user = service.validateUser(validateUser);
		if(user != null) {
			session.setAttribute(USER, user);
			service.updateCookieValue(cookieValue, user.getEmail(), response);
			redirectAttributes.addFlashAttribute("user", user);
			return new ModelAndView("redirect:/welcome");
		}
		else {
			LOGGER.error("Error");
			throw new Exception();
		}

		/*
		 * 	<#if (userNameya)??>${userNameya}<#else>boo</#if>
			<#if (user.email)??>${user.email}<#else>boo</#if>
			<#if (user)??>${user}<#else>boo</#if>
			<#if cars??>
    		<#list cars as car>${car.owner};</#list>
			</#if>
		 */
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView register(User user, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response, final RedirectAttributes redirectAttributes) throws Exception {

		if (service.insertUser(user)) {
			session.setAttribute(USER, user);
			service.updateCookieValue(cookieValue, user.getEmail(), response);
			redirectAttributes.addFlashAttribute("user", user);
			return new ModelAndView("redirect:/welcome");
		}
		else {
			throw new Exception();
		}

	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public ModelAndView welcome(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			@ModelAttribute("user") User user, HttpSession session, HttpServletResponse response) throws Exception {
		ModelAndView mv = new ModelAndView(INDEX_PAGE);
		if (user.getEmail() == null) {
			user = service.getLoggedInUser(cookieValue, session, response);
		}
		if (user != null) {
			mv.addObject(USER, user);
		}
		else {
			mv.addObject(USER, null);
		}
		return mv;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) {
		if (session.getAttribute(USER) != null) {
			session.removeAttribute(USER);
			session.invalidate();
		}
		service.endSession(cookieValue, response);
		/*if (!SESSION_COOKIE_DEFAULT.equals(cookieValue)) {
			Cookie cookie = new Cookie(SESSION_COOKIE, null);
			cookie.setMaxAge(0);
			response.addCookie(cookie);
		}*/
		return new ModelAndView("redirect:/index");
	}

	/*private void updateUserWithLoginDetails(User user) throws Exception {
		service.updateUserLastLogin(user);
	}*/

	/*private void generateCookie(String email, HttpServletResponse response) {
		String sessionId = service.startSession(email);
		if (sessionId == null) {
			//response.redirect("/internal_error");
		}
		else {
			Cookie cookie = new Cookie(SESSION_COOKIE, sessionId); //bake cookie
			cookie.setMaxAge(2592000); //set expire time to 1000 sec
			response.addCookie(cookie); //put cookie in response 
		}
	}*/

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView search(String query, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		return new ModelAndView("redirect:/product/"+query);
	}

	@RequestMapping(value = "/fetchUserByEmail", method = RequestMethod.POST)
	public Document fetchUserByEmail(@RequestBody String email) throws Exception {

		User user = service.findUserByEmail(email.replaceAll("\"", ""), false);
		if (user != null) {
			return new Document("userExists", true);
		}
		return new Document("userExists", false);
	}

	@RequestMapping(value = "/product/{productName}", method = RequestMethod.GET) 
	public ModelAndView getProduct(@PathVariable String productName, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {
		ModelAndView mv = null; 

		Phone phone = service.fetchCellPhoneById(productName);
		if (phone != null) {
			mv = new ModelAndView(PRODUCT_PAGE);
			Base64 base = new Base64();
			byte[] encodeBase64 = base.encode(phone.getImage());
			String base64Encoded = new String(encodeBase64, "UTF-8");
			phone.setInsertedBy(base64Encoded);
			mv.addObject(PHONE, phone);
		}
		else {
			mv = new ModelAndView(SEARCH_PAGE);
			Set<Phone> phoneList = service.fetchCellPhone(productName, 20);
			for (Phone it : phoneList) {
				Base64 base = new Base64();
				byte[] encodeBase64 = base.encode(it.getImage());
				String base64Encoded = new String(encodeBase64, "UTF-8");
				it.setInsertedBy(base64Encoded);
			}
			mv.addObject(PHONE_LIST, phoneList);
		}

		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		return mv;
	}

	@RequestMapping(value = {"/compare"}, method = RequestMethod.GET)
	public ModelAndView compare(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		ModelAndView mv = new ModelAndView(COMPARE_PAGE);
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		return mv;
	}

	@RequestMapping(value = "/getTags", method = RequestMethod.GET)
	public @ResponseBody
	Set<Tag> getTags(@RequestParam String tagName) throws Exception {
		Set<Tag> result = new LinkedHashSet<Tag>();

		int limit = 10; 
		Set<Phone> phoneSet = service.fetchCellPhone(tagName, limit);
		int i = 0;
		for (Phone itr : phoneSet) {
			result.add(new Tag(i++, itr.getProductId()));
		}
		return result;
	}

}
class Tag {

	public int id;
	public String tagName;

	//getter and setter methods

	public Tag(int id, String tagName) {
		this.id = id;
		this.tagName = tagName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}

}