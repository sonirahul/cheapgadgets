package com.cheapestgadget.controller;

import static com.cheapestgadget.constant.ApplicationConstants.COMPARE_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.INDEX_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.LOGIN_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.PHONE;
import static com.cheapestgadget.constant.ApplicationConstants.PHONE_LIST;
import static com.cheapestgadget.constant.ApplicationConstants.PRODUCT_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.SEARCH_PAGE;
import static com.cheapestgadget.constant.ApplicationConstants.SESSION_COOKIE;
import static com.cheapestgadget.constant.ApplicationConstants.SESSION_COOKIE_DEFAULT;
import static com.cheapestgadget.constant.ApplicationConstants.USER;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringEscapeUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.cheapestgadget.dto.product.phone.Phone;
import com.cheapestgadget.dto.user.User;
import com.cheapestgadget.service.ICheapestGadgetService;

@RestController
public class CheapestGadgetController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CheapestGadgetController.class);

	@Autowired private ICheapestGadgetService service;

	@RequestMapping(value = {"/", "/index"}, method = RequestMethod.GET)
	public ModelAndView index(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		ModelAndView mv = new ModelAndView(INDEX_PAGE);
		List<Document> posts = service.findByDateDescending();

		for (Document itr : posts) {
			String body = (String) itr.get("body");
			body = body.substring(0, body.substring(0, 300).lastIndexOf(" "));
			body = body + "... <a href=\"post/" + itr.get("permalink").toString() + "\">Read More</a>";
			itr.put("body", body);
		}
        mv.addObject("myposts", posts);
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		return mv;
	}

	@RequestMapping(value = {"/post/{permalink}"}, method = RequestMethod.GET)
	public ModelAndView viewPost(@PathVariable String permalink, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		ModelAndView mv = new ModelAndView("blogPosts");
		Document post = service.findByPermalink(permalink);

		mv.addObject("post", post);
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		return mv;
	}
	
	@RequestMapping(value = {"/newpost"}, method = RequestMethod.GET)
	public ModelAndView getNewPost(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		User user = service.getLoggedInUser(cookieValue, session, response);
		ModelAndView mv = null;
		if (user != null) {
			mv = new ModelAndView("newPost");
			mv.addObject(USER, user);
		}
		else {
			mv = new ModelAndView(LOGIN_PAGE);
		}

		return mv;
	}
	
	@RequestMapping(value = {"/newpost"}, method = RequestMethod.POST)
	public void submitNewPost(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response, HttpServletRequest request) throws Exception {

        String title = StringEscapeUtils.escapeHtml4(request.getParameter("subject"));
        String post = StringEscapeUtils.escapeHtml4(request.getParameter("body"));
        String tags = StringEscapeUtils.escapeHtml4(request.getParameter("tags"));

        User user = service.getLoggedInUser(cookieValue, session, response);

        /*ModelAndView mv = null;
        
        if (user == null) {
        	mv = new ModelAndView(LOGIN_PAGE);   // only logged in users can post to blog
        }
        else if (title.equals("") || post.equals("")) {
            // redisplay page with errors
            HashMap<String, String> root = new HashMap<String, String>();
            root.put("errors", "post must contain a title and blog entry.");
            root.put("subject", title);
            root.put("username", username);
            root.put("tags", tags);
            root.put("body", post);
            template.process(root, writer);
        }
        else {
            // extract tags
            ArrayList<String> tagsArray = extractTags(tags);

            // substitute some <p> for the paragraph breaks
            post = post.replaceAll("\\r?\\n", "<p>");

            String permalink = blogPostDAO.addPost(title, post, tagsArray, username);

            // now redirect to the blog permalink
            response.redirect("/post/" + permalink);
        }*/
    }

	@RequestMapping(value = {"/login"}, method = RequestMethod.GET)
	public ModelAndView login(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response, final RedirectAttributes redirectAttributes) throws Exception {

		ModelAndView mv = null;
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv = new ModelAndView("redirect:/welcome");
			redirectAttributes.addFlashAttribute("user", user);
		}
		else {
			mv = new ModelAndView(LOGIN_PAGE);
		}
		return mv;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView login(User validateUser, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response, final RedirectAttributes redirectAttributes) throws Exception {

		User user = service.validateUser(validateUser);
		if(user != null) {
			session.setAttribute(USER, user);
			service.updateCookieValue(cookieValue, user.getEmail(), response);
			redirectAttributes.addFlashAttribute("user", user);
			return new ModelAndView("redirect:/welcome");
		}
		else {
			LOGGER.error("Error");
			throw new Exception();
		}

		/*
		 * 	<#if (userNameya)??>${userNameya}<#else>boo</#if>
			<#if (user.email)??>${user.email}<#else>boo</#if>
			<#if (user)??>${user}<#else>boo</#if>
			<#if cars??>
    		<#list cars as car>${car.owner};</#list>
			</#if>
		 */
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView register(User user, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response, final RedirectAttributes redirectAttributes) throws Exception {

		if (service.insertUser(user)) {
			session.setAttribute(USER, user);
			service.updateCookieValue(cookieValue, user.getEmail(), response);
			redirectAttributes.addFlashAttribute("user", user);
			return new ModelAndView("redirect:/welcome");
		}
		else {
			throw new Exception();
		}
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public ModelAndView welcome(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			@ModelAttribute("user") User user, HttpSession session, HttpServletResponse response) throws Exception {
		ModelAndView mv = new ModelAndView(INDEX_PAGE);
		List<Document> posts = service.findByDateDescending();

		for (Document itr : posts) {
			String body = (String) itr.get("body");
			body = body.substring(0, body.substring(0, 300).lastIndexOf(" "));
			body = body + "... <a href=\"post/" + itr.get("permalink").toString() + "\">Read More</a>";
			itr.put("body", body);
		}

        mv.addObject("myposts", posts);
		if (user.getEmail() == null) {
			user = service.getLoggedInUser(cookieValue, session, response);
		}
		if (user != null) {
			mv.addObject(USER, user);
		}
		else {
			mv.addObject(USER, null);
		}
		return mv;
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logout(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) {
		if (session.getAttribute(USER) != null) {
			session.removeAttribute(USER);
			session.invalidate();
		}
		service.endSession(cookieValue, response);
		/*if (!SESSION_COOKIE_DEFAULT.equals(cookieValue)) {
			Cookie cookie = new Cookie(SESSION_COOKIE, null);
			cookie.setMaxAge(0);
			response.addCookie(cookie);
		}*/
		return new ModelAndView("redirect:/index");
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public ModelAndView search(String query, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		return new ModelAndView("redirect:/product/"+query);
	}

	@RequestMapping(value = "/fetchUserByEmail", method = RequestMethod.POST)
	public Document fetchUserByEmail(@RequestBody String email) throws Exception {

		User user = service.findUserByEmail(email.replaceAll("\"", ""), false);
		if (user != null) {
			return new Document("userExists", true);
		}
		return new Document("userExists", false);
	}

	@RequestMapping(value = "/product/{productName}", method = RequestMethod.GET) 
	public ModelAndView getProduct(@PathVariable String productName, 
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {
		ModelAndView mv = null; 

		productName = productName.replaceFirst("_", " ");

		Phone phone = service.fetchCellPhoneById(productName);
		if (phone != null) {
			mv = new ModelAndView(PRODUCT_PAGE);
			mv.addObject(PHONE, phone);
		}
		else {
			mv = new ModelAndView(SEARCH_PAGE);
			Set<Phone> phoneList = service.fetchCellPhone(productName, 20, true);
			mv.addObject(PHONE_LIST, phoneList);
		}

		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		return mv;
	}

	@RequestMapping(value = {"/compare"}, method = RequestMethod.GET)
	public ModelAndView compare(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		ModelAndView mv = new ModelAndView(COMPARE_PAGE);
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		return mv;
	}

	@RequestMapping(value = "/getTags", method = RequestMethod.GET)
	public @ResponseBody
	Set<Tag> getTags(@RequestParam String tagName) throws Exception {
		Set<Tag> result = new LinkedHashSet<Tag>();

		int limit = 10; 
		Set<Phone> phoneSet = service.fetchCellPhone(tagName, limit, false);
		int i = 0;
		for (Phone itr : phoneSet) {
			result.add(new Tag(i++, itr.getProductId()));
		}
		return result;
	}

	@RequestMapping(value = {"/phoneFinder"}, method = RequestMethod.GET)
	public ModelAndView phoneFinder(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		ModelAndView mv = new ModelAndView("finder");
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		mv.addObject("phoneFinder", service.updateCache());
		return mv;
	}

	@RequestMapping(value = {"/uploader"}, method = RequestMethod.GET)
	public ModelAndView getUploader(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response) throws Exception {

		ModelAndView mv = new ModelAndView("uploader");
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		mv.addObject("phoneFinder", service.updateCache());
		return mv;
	}
	
	@RequestMapping(value = {"/uploader"}, method = RequestMethod.POST)
	public ModelAndView submitUploader(
			@CookieValue(value = SESSION_COOKIE, defaultValue = SESSION_COOKIE_DEFAULT) String cookieValue, 
			HttpSession session, HttpServletResponse response, HttpServletRequest request) throws Exception {


        String title = StringEscapeUtils.escapeHtml4(request.getParameter("productName"));
        String post = StringEscapeUtils.escapeHtml4(request.getParameter("manufacturer"));
        String tags = StringEscapeUtils.escapeHtml4(request.getParameter("modelName"));
        
        System.out.println("testing productName:" + title + ", manufacturer:" + post + ", modelName:" + tags);

		ModelAndView mv = new ModelAndView("uploader");
		User user = service.getLoggedInUser(cookieValue, session, response);
		if (user != null) {
			mv.addObject(USER, user);
		}
		mv.addObject("phoneFinder", service.updateCache());
		return mv;
	}
}
class Tag {

	public int id;
	public String tagName;

	//getter and setter methods

	public Tag(int id, String tagName) {
		this.id = id;
		this.tagName = tagName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTagName() {
		return tagName;
	}

	public void setTagName(String tagName) {
		this.tagName = tagName;
	}
}