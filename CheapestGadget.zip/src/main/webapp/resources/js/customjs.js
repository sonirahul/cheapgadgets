$(document).ready(function () {
	areCookiesEnabled();
$('#query').autocomplete(
    {
        serviceUrl : contextPath+'/getTags',
        paramName : "tagName",
        delimiter : ",",
        onSelect: function (item) {
        	var url = item.value;
            if(url != '#') {
                location.href = contextPath+'/product/' + url;
            }
          },
        transformResult : function(response) {

            return {
                suggestions : $.map($.parseJSON(response),
                    function(item) {
                        return {
                            value : item.tagName,
                            data : item.id
                        };
                    })
            };
        }
    });
});